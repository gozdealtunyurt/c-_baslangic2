﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S2.D1.RegionKullanimi
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Yorum Satırı");

            /*
             * Console.WriteLine("Yorum Satırı");
             * Console.WriteLine("Yorum Satırı");
             * Console.WriteLine("Yorum Satırı");
             * 
             * 
             */

            #region Musteri Islemlerim 

            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");

            #endregion

            #region Operasyonel İşlemler 
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
#endregion

            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");
            Console.WriteLine("Yorum Satırı");

        }
    }
}
