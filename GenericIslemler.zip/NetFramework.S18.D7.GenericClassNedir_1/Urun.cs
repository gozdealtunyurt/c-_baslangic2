﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S18.D7.GenericClassNedir_1
{
    public class Urun
    {
        public int id { get; set; }
        public string tanim { get; set; }
    }
}
