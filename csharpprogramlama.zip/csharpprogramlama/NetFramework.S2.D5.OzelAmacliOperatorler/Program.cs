﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S2.D5.OzelAmacliOperatorler
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * ?: if else 
             * () : boxing - unboxing işlemlerinde kullandık. 
             * [] : diziler konusunda inceleyeceğiz. 
             * new : class konusunda inceleyeceğiz. 
             * typeof() : ... 
             * 
             */
        }
    }
}
