﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S17.D1.EnumNedir
{
    public enum musteriReturnValue
    {
        kayitBasarili = 717770001,
        kayitBasarisiz = 717770002,
        varolanMusteri = 717770003,
        parametreHatasi,
        calismaZamaniHatasi
    }
}
