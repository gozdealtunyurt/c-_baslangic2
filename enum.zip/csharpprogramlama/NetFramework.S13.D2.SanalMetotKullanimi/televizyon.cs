﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S13.D2.SanalMetotKullanimi
{
    public class televizyon:urun
    {
        public televizyon()
        {
            Console.WriteLine("televizyon");
        }
    }
}
