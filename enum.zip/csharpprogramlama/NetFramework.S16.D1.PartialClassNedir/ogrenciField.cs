﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S16.D1.PartialClassNedir
{
    public partial class ogrenci
    {
        public int id { get; set; }
        public string isim { get; set; }
        public string soyisim { get; set; }
        public string ogrenciNumarasi { get; set; }
    }
}
