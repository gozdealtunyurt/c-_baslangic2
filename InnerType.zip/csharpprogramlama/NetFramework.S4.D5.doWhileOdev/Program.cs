﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S4.D5.doWhileOdev
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Odev 1 : Kullanıcıyı do while içerisine alın ve kullanıcı adı ve password sorun. Kullanıcı adı : Demo Şifre : Demo eğer kullanıcı bu değerleri bilirse döngüden çıkın ve başarılı yazın. Eğer yanlış giriş yapıyorsa do while ile ilgili değerleri sormaya devam edin.

            #endregion

            #region Odev 2 : Kullanıcıdan 1 ile X arasında bir sayı girmesini isteyin. Daha sonra sistem kullanıcının girmiş olduğu 1 ile X değerleri arasında bir sayı tahmini yapsın. Daha sonra kullanıcu sistemin tahmin etmiş olduğu sayıyı bulmaya çalışssın. Bulamaz ise yeniden yeniden sorsun. Ne zaman kullanıcı ilgili değeri bulursa Y kadar denediniz ve sonuca ulaştınız desin. 
            #endregion
        }
    }
}
