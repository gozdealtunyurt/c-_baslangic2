﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetFramework.S1.D3.SabitTanimlar
{
    class Program
    {
        static void Main(string[] args)
        {
            int sayi1 = 10;

            sayi1 = 1111;

            const int ortakBolumDeger = 2;
            

            int Sonuc = sayi1 / ortakBolumDeger;

           // ortakBolumDeger = ortakBolumDeger + 3;



        }
    }
}
